function acceptCookies(acceptButton) {
    acceptButton.parentNode.remove();
}

function emptyCartAlert() {
    alert("Your Cart is empty");
}